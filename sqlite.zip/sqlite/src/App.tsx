import React, { useState } from 'react';
import './App.css';
import UserList from './components/UserList';
import UserForm from './components/UserForm';

const App: React.FC = () => {
  const [selectedUser, setSelectedUser] = useState<{
    email: string;
    firstName: string;
    lastName: string;
    class_field?: string;
  } | null>(null);

  const handleUserSaved = () => {
    setSelectedUser(null);  // Az adat mentése után nullázza a kiválasztott felhasználót
  };

  return (
    <div className="App">
      <h1>User Management</h1>
      <UserForm user={selectedUser} onUserSaved={handleUserSaved} />
      <UserList />
    </div>
  );
}

export default App;
