import React, { useEffect, useState } from 'react';
import axios from '../axios';
import User from './User';

interface User {
  email: string;
  firstName: string;
  lastName: string;
  class_field?: string;
}

const UserList: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    axios.get('/users')
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the users!", error);
      });
  }, []);

  return (
    <div>
      <h2>Users List</h2>
      <ul>
        {users.map((user) => (
          <User key={user.email} user={user} />
        ))}
      </ul>
    </div>
  );
};

export default UserList;
