import React from 'react';
import axios from '../axios';

interface UserProps {
  user: {
    email: string;
    firstName: string;
    lastName: string;
    class_field?: string;
  };
}

const User: React.FC<UserProps> = ({ user }) => {
  const deleteUser = () => {
    axios.delete(`/users/${user.email}`)
      .then(() => {
        alert('User deleted');
        window.location.reload();
      })
      .catch((error) => {
        console.error("There was an error deleting the user!", error);
      });
  };

  return (
    <li>
      {user.firstName} {user.lastName} - {user.email}
      <button onClick={deleteUser}>Delete</button>
    </li>
  );
};

export default User;
