import React, { useState, useEffect } from 'react';
import axios from '../axios';

interface UserFormProps {
  user?: {
    email: string;
    firstName: string;
    lastName: string;
    class_field?: string;
  };
  onUserSaved: () => void;
}

const UserForm: React.FC<UserFormProps> = ({ user, onUserSaved }) => {
  const [email, setEmail] = useState(user?.email || '');
  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const [classField, setClassField] = useState(user?.class_field || '');

  useEffect(() => {
    if (user) {
      setEmail(user.email);
      setFirstName(user.firstName);
      setLastName(user.lastName);
      setClassField(user.class_field || '');
    }
  }, [user]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const userData = { email, firstName, lastName, class_field: classField };

    if (user) {
      // Módosítás esetén
      axios.put(`/users/${user.email}`, userData)
        .then(() => {
          alert('User updated');
          onUserSaved();
        })
        .catch((error) => {
          console.error('There was an error updating the user!', error);
        });
    } else {
      // Új felhasználó létrehozása
      axios.post('/users', userData)
        .then(() => {
          alert('User created');
          onUserSaved();
        })
        .catch((error) => {
          console.error('There was an error creating the user!', error);
        });
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>{user ? 'Edit User' : 'Add New User'}</h2>
      <div>
        <label>Email</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div>
        <label>First Name</label>
        <input
          type="text"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          required
        />
      </div>
      <div>
        <label>Last Name</label>
        <input
          type="text"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
          required
        />
      </div>
      <div>
        <label>Class</label>
        <input
          type="text"
          value={classField}
          onChange={(e) => setClassField(e.target.value)}
        />
      </div>
      <button type="submit">Save</button>
    </form>
  );
};

export default UserForm;
